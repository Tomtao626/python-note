import calc

print(calc.add(99, 88))
