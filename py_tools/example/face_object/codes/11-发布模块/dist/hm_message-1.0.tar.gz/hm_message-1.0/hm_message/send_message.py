# -*- coding: utf-8 -*-
'''
encoding: utf-8
Author    : tom_tao626@163.com >
Datetime  : 2019/10/20 19:22
User      : Administrator
Product   : PyCharm
Project   : codes
File      : send_message.py
'''
def send_msg(text):
    print("正在发送%s"%text)