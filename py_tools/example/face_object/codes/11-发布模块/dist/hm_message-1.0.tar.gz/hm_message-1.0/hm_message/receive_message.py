# -*- coding: utf-8 -*-
'''
encoding: utf-8
Author    : tom_tao626@163.com >
Datetime  : 2019/10/20 19:23
User      : Administrator
Product   : PyCharm
Project   : codes
File      : receive_message.py
'''
def receive_msg():
    return "这是来自100xx的短信"